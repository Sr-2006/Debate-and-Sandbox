# FULL 22-CASE RCA ENGINE VALIDATION REPORT
**Execution Timestamp:** `2026-08-11T14:31:49Z`  
**Total Scenarios Evaluated:** `12`  

---
## Results Matrix

| Test Case | Execution Tier | Score (%) | Safety Veto | Latency (s) |
| :--- | :--- | :---: | :---: | :---: |
| `case_11_pg_connection_exhaustion.json` | `TIER_2_SHADOW_SANDBOX` | `83%` | `False` | `75.64s` |
| `case_12_redis_memory_eviction.json` | `TIER_2_SHADOW_SANDBOX` | `83%` | `False` | `63.32s` |
| `case_13_dns_resolution_failure.json` | `TIER_2_SHADOW_SANDBOX` | `83%` | `False` | `58.64s` |
| `case_14_disk_pressure_wal.json` | `TIER_2_SHADOW_SANDBOX` | `80%` | `False` | `72.7s` |
| `case_15_cpu_throttling.json` | `TIER_2_SHADOW_SANDBOX` | `80%` | `False` | `61.98s` |
| `case_16_rabbitmq_queue_backlog.json` | `TIER_2_SHADOW_SANDBOX` | `58%` | `False` | `100.76s` |
| `case_17_tls_cert_expiry.json` | `TIER_2_SHADOW_SANDBOX` | `68%` | `False` | `51.98s` |
| `case_18_kernel_panic.json` | `TIER_2_SHADOW_SANDBOX` | `63%` | `False` | `104.92s` |
| `case_19_bpf_filter_drop.json` | `TIER_2_SHADOW_SANDBOX` | `63%` | `False` | `92.66s` |
| `case_20_grpc_stream_deadlock.json` | `TIER_2_SHADOW_SANDBOX` | `83%` | `False` | `69.68s` |
| `case_21_ingress_rate_limit.json` | `TIER_2_SHADOW_SANDBOX` | `63%` | `False` | `98.04s` |
| `case_22_storage_corruption_nuclear.json` | `TIER_2_SHADOW_SANDBOX` | `81%` | `False` | `63.29s` |