"""Output publisher for the Phase 3 -> Phase 4 integration.

The debate's conclusion is published as an `autosre.action.proposed` message to
RabbitMQ for Phase 4. Per the handover brief:
- If any proposed command trips the semantic veto (cosine >= 0.82 against
  FORBIDDEN_CENTROIDS), confidence is capped at 64% and the action routes to
  human review.
- The debate engine itself never executes commands; it only proposes.

RabbitMQ (pika) is optional at import time so the engine still runs in
offline/test mode and can emit the message to stdout or a JSON file instead.
"""

from __future__ import annotations

import json
import os
import uuid
from datetime import datetime, timezone
from typing import Any

from config import BASE_DIR

ROUTING_KEY = "autosre.action.proposed"
EXCHANGE = os.environ.get("AUTOSRE_EXCHANGE", "autosre")
RABBITMQ_URL = os.environ.get("RABBITMQ_URL", "amqp://guest:guest@localhost:5672/")

# Veto cap defined by the integration contract.
VETO_CONFIDENCE_CAP = 64


def build_action_proposed(
    incident_id: str,
    result: dict,
    correlation_id: str | None = None,
    fingerprint: str | None = None,
) -> dict:
    """Convert a DebateManager result into the `autosre.action.proposed` envelope.

    `result` is the dict returned by `DebateManager.run_async()`.
    """
    solution = result.get("solution", {}) if isinstance(result, dict) else {}
    confidence = int(result.get("confidence_score", 0) or 0)
    safety_violation = bool(result.get("safety_violation"))

    # Contract: veto -> cap at 64% and force human review.
    if safety_violation:
        confidence = min(confidence, VETO_CONFIDENCE_CAP)

    execution_tier = result.get("execution_tier", "TIER_2_SHADOW_SANDBOX")
    if safety_violation:
        execution_tier = "HUMAN_REVIEW"

    action_commands = solution.get("action_commands", [])
    if not isinstance(action_commands, list):
        action_commands = [str(action_commands)] if action_commands else []

    return {
        "event_type": "action.proposed",
        "incident_id": incident_id,
        "correlation_id": correlation_id or str(uuid.uuid4()),
        "fingerprint": fingerprint,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "payload": {
            "consensus_rc": solution.get("consensus_rc", ""),
            "primary_component": solution.get("primary_component", "unknown"),
            "action_commands": action_commands,
            "runbook": solution.get("final_rca") or solution.get("final_triage") or "",
            "confidence": confidence,
            "execution_tier": execution_tier,
            "safety_violation": safety_violation,
            "veto_reason": (solution.get("scoring_metadata") or {}).get("veto_reason"),
            "consensus_quality": solution.get("consensus_quality", "LOW"),
            "round_2_executed": result.get("round_2_executed", False),
            "total_latency_seconds": result.get("total_latency_seconds"),
        },
    }


class ActionPublisher:
    """Publishes `autosre.action.proposed` to RabbitMQ, with offline fallbacks."""

    def __init__(self, rabbitmq_url: str = RABBITMQ_URL, exchange: str = EXCHANGE):
        self.rabbitmq_url = rabbitmq_url
        self.exchange = exchange

    def publish(self, message: dict, offline_dir: str | None = None) -> dict:
        """Publish the message. Returns {'transport': ..., 'ok': bool, 'detail': ...}.

        Tries RabbitMQ first; if pika is unavailable or the broker is unreachable,
        falls back to writing the message as JSON (offline mode) so Phase 4 can
        still consume it from disk.
        """
        body = json.dumps(message, ensure_ascii=False, default=str)

        # Attempt live publish.
        try:
            import pika  # type: ignore

            params = pika.URLParameters(self.rabbitmq_url)
            connection = pika.BlockingConnection(params)
            channel = connection.channel()
            channel.exchange_declare(exchange=self.exchange, exchange_type="topic", durable=True)
            channel.basic_publish(
                exchange=self.exchange,
                routing_key=ROUTING_KEY,
                body=body.encode("utf-8"),
                properties=pika.BasicProperties(delivery_mode=2, content_type="application/json"),
            )
            connection.close()
            return {"transport": "rabbitmq", "ok": True, "detail": ROUTING_KEY}
        except ImportError:
            pass
        except Exception as e:  # broker down / unreachable -> offline fallback
            detail = f"rabbitmq unavailable ({e}); falling back to file"
            return self._write_offline(message, offline_dir, detail)

        return self._write_offline(message, offline_dir, "pika not installed; offline mode")

    @staticmethod
    def _write_offline(message: dict, offline_dir: str | None, detail: str) -> dict:
        out_dir = offline_dir or os.path.join(BASE_DIR, "output", "proposed_actions")
        os.makedirs(out_dir, exist_ok=True)
        incident_id = message.get("incident_id", "incident")
        path = os.path.join(out_dir, f"{incident_id}.action_proposed.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(message, f, ensure_ascii=False, indent=2, default=str)
        return {"transport": "file", "ok": True, "detail": f"{detail} -> {path}"}
